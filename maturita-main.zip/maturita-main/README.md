<p align="center">
  <h1 align="center">SPŠ a VOŠ Chomutov - Maturitní praktická zkouška (Programování)</h1>
  
  <br />

  <p align="center">
    <a href="https://github.com/DrGumik/maturita">
      <img src="https://img.shields.io/static/v1?label=DrGumik&message=maturita&color=yellow&logo=github" alt="DrGumik - maturita">
    </a>
    <a href="https://github.com/DrGumik/maturita/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-MIT-blueviolet" alt="License"></a>
   </p>
</p>



<!-- TABLE OF CONTENTS -->
## Seznam projektů
<ol>
  <li>
    Sériová linka (C# + ASM)
  </li>
  <li>
    Maticový displej (ASM)
  </li>
  <li>
    Mikrovlnka (C - MSDOS)
  </li>
  <li>
    Piškvorky (C#)
  </li>
  <li>
    Robot (C - MSDOS)
  </li>
  <li>
    Výtah (C - MSDOS)
  </li>
   <li>
    Alfanumerický displej (C - MSDOS)
  </li>
  <li>
    Křižovatka (C#)
  </li>
  <li>
    Knihovna (C#)
  </li>
</ol>

<!-- CONTACT -->
## Kontakt

Jakub Tenk - [@twitter](https://twitter.com/DrGumik)

Project Link: [https://github.com/DrGumik/maturita](https://github.com/DrGumik/maturita)

<!-- LICENSE -->
## Licence

Released under <a href="/LICENSE">MIT</a> by <a href="https://github.com/DrGumik">@Jakub Tenk</a>.
