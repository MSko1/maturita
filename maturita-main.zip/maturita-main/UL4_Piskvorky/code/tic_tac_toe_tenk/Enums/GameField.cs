﻿namespace tic_tac_toe_tenk.Enums
{
    public enum GameField
    {
        NotOccupied,
        X,
        O
    }
}
