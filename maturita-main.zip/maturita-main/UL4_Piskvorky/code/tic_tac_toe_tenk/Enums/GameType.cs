﻿namespace tic_tac_toe_tenk.Enums
{
    public enum GameType
    {
        PvP,
        PvA
    }
}
