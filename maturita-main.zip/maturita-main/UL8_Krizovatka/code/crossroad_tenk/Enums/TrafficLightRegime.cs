﻿namespace crossroad_tenk.Enums
{
    public enum TrafficLightRegime
    {
        Day,
        Night
    }
}
