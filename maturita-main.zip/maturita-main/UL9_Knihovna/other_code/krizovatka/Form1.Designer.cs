﻿namespace krizovatka
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.hlavni_z1 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.hlavni_z2 = new System.Windows.Forms.Panel();
            this.silnice2 = new System.Windows.Forms.Panel();
            this.odbocka_1 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.odbocka_2 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.vedlejsi_zel2 = new System.Windows.Forms.Panel();
            this.vedlejsi_z2 = new System.Windows.Forms.Panel();
            this.vedlejsi_c2 = new System.Windows.Forms.Panel();
            this.vedlejsi_zel1 = new System.Windows.Forms.Panel();
            this.vedlejsi_z1 = new System.Windows.Forms.Panel();
            this.vedlejsi_c1 = new System.Windows.Forms.Panel();
            this.hlavni_zel1 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.hl_zat_zel2 = new System.Windows.Forms.Panel();
            this.hlavni_zel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.hl_zat_z2 = new System.Windows.Forms.Panel();
            this.hl_zat_c2 = new System.Windows.Forms.Panel();
            this.hlavni_c2 = new System.Windows.Forms.Panel();
            this.hlavni_c1 = new System.Windows.Forms.Panel();
            this.rezimy = new System.Windows.Forms.GroupBox();
            this.rezim_noc = new System.Windows.Forms.RadioButton();
            this.rezim_den = new System.Windows.Forms.RadioButton();
            this.chodci_vedl_c2 = new System.Windows.Forms.Panel();
            this.chodci_vedl_zel4 = new System.Windows.Forms.Panel();
            this.chodci_vedl_zel2 = new System.Windows.Forms.Panel();
            this.chodci_vedl_c4 = new System.Windows.Forms.Panel();
            this.chodci_vedl_c1 = new System.Windows.Forms.Panel();
            this.chodci_vedl_zel1 = new System.Windows.Forms.Panel();
            this.chodci_vedl_zel3 = new System.Windows.Forms.Panel();
            this.chodci_vedl_c3 = new System.Windows.Forms.Panel();
            this.chodci_hl_c4 = new System.Windows.Forms.Panel();
            this.chodci_hl_c2 = new System.Windows.Forms.Panel();
            this.chodci_hl_zel4 = new System.Windows.Forms.Panel();
            this.chodci_hl_zel2 = new System.Windows.Forms.Panel();
            this.chodci_hl_zel3 = new System.Windows.Forms.Panel();
            this.chodci_hl_c3 = new System.Windows.Forms.Panel();
            this.chodci_hl_zel1 = new System.Windows.Forms.Panel();
            this.chodci_hl_c1 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.silnice1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.hl_zat_zel1 = new System.Windows.Forms.Panel();
            this.hl_zat_z1 = new System.Windows.Forms.Panel();
            this.hl_zat_c1 = new System.Windows.Forms.Panel();
            this.cas = new System.Windows.Forms.Timer(this.components);
            this.pripojeni = new System.Windows.Forms.Button();
            this.odpojeni = new System.Windows.Forms.Button();
            this.start = new System.Windows.Forms.Button();
            this.stop = new System.Windows.Forms.Button();
            this.label_log = new System.Windows.Forms.Label();
            this.silnice2.SuspendLayout();
            this.rezimy.SuspendLayout();
            this.silnice1.SuspendLayout();
            this.SuspendLayout();
            // 
            // hlavni_z1
            // 
            this.hlavni_z1.BackColor = System.Drawing.Color.White;
            this.hlavni_z1.Location = new System.Drawing.Point(143, 557);
            this.hlavni_z1.Name = "hlavni_z1";
            this.hlavni_z1.Size = new System.Drawing.Size(30, 30);
            this.hlavni_z1.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Location = new System.Drawing.Point(344, 13);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(50, 20);
            this.panel17.TabIndex = 8;
            // 
            // hlavni_z2
            // 
            this.hlavni_z2.BackColor = System.Drawing.Color.White;
            this.hlavni_z2.Location = new System.Drawing.Point(29, 111);
            this.hlavni_z2.Name = "hlavni_z2";
            this.hlavni_z2.Size = new System.Drawing.Size(30, 30);
            this.hlavni_z2.TabIndex = 2;
            // 
            // silnice2
            // 
            this.silnice2.BackColor = System.Drawing.Color.Gray;
            this.silnice2.Controls.Add(this.odbocka_1);
            this.silnice2.Controls.Add(this.panel18);
            this.silnice2.Controls.Add(this.odbocka_2);
            this.silnice2.Controls.Add(this.panel19);
            this.silnice2.Controls.Add(this.panel17);
            this.silnice2.Controls.Add(this.panel20);
            this.silnice2.Controls.Add(this.panel16);
            this.silnice2.Controls.Add(this.panel21);
            this.silnice2.Controls.Add(this.panel15);
            this.silnice2.Controls.Add(this.panel22);
            this.silnice2.Controls.Add(this.panel14);
            this.silnice2.Controls.Add(this.panel23);
            this.silnice2.Controls.Add(this.panel13);
            this.silnice2.Controls.Add(this.panel24);
            this.silnice2.Controls.Add(this.panel12);
            this.silnice2.Controls.Add(this.panel11);
            this.silnice2.Controls.Add(this.vedlejsi_zel2);
            this.silnice2.Controls.Add(this.vedlejsi_z2);
            this.silnice2.Controls.Add(this.vedlejsi_c2);
            this.silnice2.Controls.Add(this.vedlejsi_zel1);
            this.silnice2.Controls.Add(this.vedlejsi_z1);
            this.silnice2.Controls.Add(this.vedlejsi_c1);
            this.silnice2.Location = new System.Drawing.Point(-8, 231);
            this.silnice2.Name = "silnice2";
            this.silnice2.Size = new System.Drawing.Size(1000, 200);
            this.silnice2.TabIndex = 17;
            // 
            // odbocka_1
            // 
            this.odbocka_1.BackColor = System.Drawing.Color.White;
            this.odbocka_1.Location = new System.Drawing.Point(290, 153);
            this.odbocka_1.Name = "odbocka_1";
            this.odbocka_1.Size = new System.Drawing.Size(30, 30);
            this.odbocka_1.TabIndex = 3;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.White;
            this.panel18.Location = new System.Drawing.Point(606, 13);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(50, 20);
            this.panel18.TabIndex = 10;
            // 
            // odbocka_2
            // 
            this.odbocka_2.BackColor = System.Drawing.Color.White;
            this.odbocka_2.Location = new System.Drawing.Point(683, 19);
            this.odbocka_2.Name = "odbocka_2";
            this.odbocka_2.Size = new System.Drawing.Size(30, 30);
            this.odbocka_2.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.White;
            this.panel19.Location = new System.Drawing.Point(606, 169);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(50, 20);
            this.panel19.TabIndex = 11;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.White;
            this.panel20.Location = new System.Drawing.Point(606, 143);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(50, 20);
            this.panel20.TabIndex = 12;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.White;
            this.panel16.Location = new System.Drawing.Point(344, 169);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(50, 20);
            this.panel16.TabIndex = 8;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.White;
            this.panel21.Location = new System.Drawing.Point(606, 117);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(50, 20);
            this.panel21.TabIndex = 13;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.White;
            this.panel15.Location = new System.Drawing.Point(344, 143);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(50, 20);
            this.panel15.TabIndex = 8;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Location = new System.Drawing.Point(606, 91);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(50, 20);
            this.panel22.TabIndex = 14;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.White;
            this.panel14.Location = new System.Drawing.Point(344, 117);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(50, 20);
            this.panel14.TabIndex = 8;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Location = new System.Drawing.Point(606, 65);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(50, 20);
            this.panel23.TabIndex = 15;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Location = new System.Drawing.Point(344, 91);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(50, 20);
            this.panel13.TabIndex = 8;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Location = new System.Drawing.Point(606, 39);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(50, 20);
            this.panel24.TabIndex = 9;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Location = new System.Drawing.Point(344, 65);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(50, 20);
            this.panel12.TabIndex = 8;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Location = new System.Drawing.Point(344, 39);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(50, 20);
            this.panel11.TabIndex = 7;
            // 
            // vedlejsi_zel2
            // 
            this.vedlejsi_zel2.BackColor = System.Drawing.Color.White;
            this.vedlejsi_zel2.Location = new System.Drawing.Point(755, 55);
            this.vedlejsi_zel2.Name = "vedlejsi_zel2";
            this.vedlejsi_zel2.Size = new System.Drawing.Size(30, 30);
            this.vedlejsi_zel2.TabIndex = 3;
            // 
            // vedlejsi_z2
            // 
            this.vedlejsi_z2.BackColor = System.Drawing.Color.White;
            this.vedlejsi_z2.Location = new System.Drawing.Point(719, 55);
            this.vedlejsi_z2.Name = "vedlejsi_z2";
            this.vedlejsi_z2.Size = new System.Drawing.Size(30, 30);
            this.vedlejsi_z2.TabIndex = 3;
            // 
            // vedlejsi_c2
            // 
            this.vedlejsi_c2.BackColor = System.Drawing.Color.White;
            this.vedlejsi_c2.Location = new System.Drawing.Point(683, 55);
            this.vedlejsi_c2.Name = "vedlejsi_c2";
            this.vedlejsi_c2.Size = new System.Drawing.Size(30, 30);
            this.vedlejsi_c2.TabIndex = 2;
            // 
            // vedlejsi_zel1
            // 
            this.vedlejsi_zel1.BackColor = System.Drawing.Color.White;
            this.vedlejsi_zel1.Location = new System.Drawing.Point(218, 117);
            this.vedlejsi_zel1.Name = "vedlejsi_zel1";
            this.vedlejsi_zel1.Size = new System.Drawing.Size(30, 30);
            this.vedlejsi_zel1.TabIndex = 2;
            // 
            // vedlejsi_z1
            // 
            this.vedlejsi_z1.BackColor = System.Drawing.Color.White;
            this.vedlejsi_z1.Location = new System.Drawing.Point(254, 117);
            this.vedlejsi_z1.Name = "vedlejsi_z1";
            this.vedlejsi_z1.Size = new System.Drawing.Size(30, 30);
            this.vedlejsi_z1.TabIndex = 2;
            // 
            // vedlejsi_c1
            // 
            this.vedlejsi_c1.BackColor = System.Drawing.Color.White;
            this.vedlejsi_c1.Location = new System.Drawing.Point(290, 117);
            this.vedlejsi_c1.Name = "vedlejsi_c1";
            this.vedlejsi_c1.Size = new System.Drawing.Size(30, 30);
            this.vedlejsi_c1.TabIndex = 1;
            // 
            // hlavni_zel1
            // 
            this.hlavni_zel1.BackColor = System.Drawing.Color.White;
            this.hlavni_zel1.Location = new System.Drawing.Point(143, 593);
            this.hlavni_zel1.Name = "hlavni_zel1";
            this.hlavni_zel1.Size = new System.Drawing.Size(30, 30);
            this.hlavni_zel1.TabIndex = 2;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.White;
            this.panel28.Location = new System.Drawing.Point(13, 194);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(20, 50);
            this.panel28.TabIndex = 7;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(143, 194);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(20, 50);
            this.panel7.TabIndex = 10;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(117, 194);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(20, 50);
            this.panel8.TabIndex = 11;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Location = new System.Drawing.Point(91, 194);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(20, 50);
            this.panel9.TabIndex = 12;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Location = new System.Drawing.Point(65, 194);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(20, 50);
            this.panel10.TabIndex = 13;
            // 
            // hl_zat_zel2
            // 
            this.hl_zat_zel2.BackColor = System.Drawing.Color.White;
            this.hl_zat_zel2.Location = new System.Drawing.Point(81, 75);
            this.hl_zat_zel2.Name = "hl_zat_zel2";
            this.hl_zat_zel2.Size = new System.Drawing.Size(30, 30);
            this.hl_zat_zel2.TabIndex = 3;
            // 
            // hlavni_zel2
            // 
            this.hlavni_zel2.BackColor = System.Drawing.Color.White;
            this.hlavni_zel2.Location = new System.Drawing.Point(29, 75);
            this.hlavni_zel2.Name = "hlavni_zel2";
            this.hlavni_zel2.Size = new System.Drawing.Size(30, 30);
            this.hlavni_zel2.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(169, 194);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(20, 50);
            this.panel6.TabIndex = 9;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Location = new System.Drawing.Point(39, 194);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(20, 50);
            this.panel27.TabIndex = 8;
            // 
            // hl_zat_z2
            // 
            this.hl_zat_z2.BackColor = System.Drawing.Color.White;
            this.hl_zat_z2.Location = new System.Drawing.Point(81, 111);
            this.hl_zat_z2.Name = "hl_zat_z2";
            this.hl_zat_z2.Size = new System.Drawing.Size(30, 30);
            this.hl_zat_z2.TabIndex = 3;
            // 
            // hl_zat_c2
            // 
            this.hl_zat_c2.BackColor = System.Drawing.Color.White;
            this.hl_zat_c2.Location = new System.Drawing.Point(81, 147);
            this.hl_zat_c2.Name = "hl_zat_c2";
            this.hl_zat_c2.Size = new System.Drawing.Size(30, 30);
            this.hl_zat_c2.TabIndex = 2;
            // 
            // hlavni_c2
            // 
            this.hlavni_c2.BackColor = System.Drawing.Color.White;
            this.hlavni_c2.Location = new System.Drawing.Point(29, 147);
            this.hlavni_c2.Name = "hlavni_c2";
            this.hlavni_c2.Size = new System.Drawing.Size(30, 30);
            this.hlavni_c2.TabIndex = 1;
            // 
            // hlavni_c1
            // 
            this.hlavni_c1.BackColor = System.Drawing.Color.White;
            this.hlavni_c1.Location = new System.Drawing.Point(143, 521);
            this.hlavni_c1.Name = "hlavni_c1";
            this.hlavni_c1.Size = new System.Drawing.Size(30, 30);
            this.hlavni_c1.TabIndex = 0;
            // 
            // rezimy
            // 
            this.rezimy.BackColor = System.Drawing.Color.White;
            this.rezimy.Controls.Add(this.rezim_noc);
            this.rezimy.Controls.Add(this.rezim_den);
            this.rezimy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rezimy.Location = new System.Drawing.Point(770, 25);
            this.rezimy.Name = "rezimy";
            this.rezimy.Size = new System.Drawing.Size(152, 67);
            this.rezimy.TabIndex = 33;
            this.rezimy.TabStop = false;
            this.rezimy.Text = "Režimy";
            // 
            // rezim_noc
            // 
            this.rezim_noc.AutoSize = true;
            this.rezim_noc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rezim_noc.Location = new System.Drawing.Point(89, 28);
            this.rezim_noc.Name = "rezim_noc";
            this.rezim_noc.Size = new System.Drawing.Size(55, 24);
            this.rezim_noc.TabIndex = 1;
            this.rezim_noc.TabStop = true;
            this.rezim_noc.Text = "Noc";
            this.rezim_noc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rezim_noc.UseVisualStyleBackColor = true;
            // 
            // rezim_den
            // 
            this.rezim_den.AutoSize = true;
            this.rezim_den.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rezim_den.Location = new System.Drawing.Point(15, 28);
            this.rezim_den.Name = "rezim_den";
            this.rezim_den.Size = new System.Drawing.Size(57, 24);
            this.rezim_den.TabIndex = 0;
            this.rezim_den.TabStop = true;
            this.rezim_den.Text = "Den";
            this.rezim_den.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rezim_den.UseVisualStyleBackColor = true;
            // 
            // chodci_vedl_c2
            // 
            this.chodci_vedl_c2.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_c2.Location = new System.Drawing.Point(307, 437);
            this.chodci_vedl_c2.Name = "chodci_vedl_c2";
            this.chodci_vedl_c2.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_c2.TabIndex = 32;
            // 
            // chodci_vedl_zel4
            // 
            this.chodci_vedl_zel4.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_zel4.Location = new System.Drawing.Point(307, 175);
            this.chodci_vedl_zel4.Name = "chodci_vedl_zel4";
            this.chodci_vedl_zel4.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_zel4.TabIndex = 28;
            // 
            // chodci_vedl_zel2
            // 
            this.chodci_vedl_zel2.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_zel2.Location = new System.Drawing.Point(307, 467);
            this.chodci_vedl_zel2.Name = "chodci_vedl_zel2";
            this.chodci_vedl_zel2.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_zel2.TabIndex = 31;
            // 
            // chodci_vedl_c4
            // 
            this.chodci_vedl_c4.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_c4.Location = new System.Drawing.Point(307, 205);
            this.chodci_vedl_c4.Name = "chodci_vedl_c4";
            this.chodci_vedl_c4.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_c4.TabIndex = 26;
            // 
            // chodci_vedl_c1
            // 
            this.chodci_vedl_c1.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_c1.Location = new System.Drawing.Point(657, 437);
            this.chodci_vedl_c1.Name = "chodci_vedl_c1";
            this.chodci_vedl_c1.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_c1.TabIndex = 30;
            // 
            // chodci_vedl_zel1
            // 
            this.chodci_vedl_zel1.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_zel1.Location = new System.Drawing.Point(657, 467);
            this.chodci_vedl_zel1.Name = "chodci_vedl_zel1";
            this.chodci_vedl_zel1.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_zel1.TabIndex = 29;
            // 
            // chodci_vedl_zel3
            // 
            this.chodci_vedl_zel3.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_zel3.Location = new System.Drawing.Point(657, 175);
            this.chodci_vedl_zel3.Name = "chodci_vedl_zel3";
            this.chodci_vedl_zel3.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_zel3.TabIndex = 24;
            // 
            // chodci_vedl_c3
            // 
            this.chodci_vedl_c3.BackColor = System.Drawing.Color.White;
            this.chodci_vedl_c3.Location = new System.Drawing.Point(657, 205);
            this.chodci_vedl_c3.Name = "chodci_vedl_c3";
            this.chodci_vedl_c3.Size = new System.Drawing.Size(20, 20);
            this.chodci_vedl_c3.TabIndex = 23;
            // 
            // chodci_hl_c4
            // 
            this.chodci_hl_c4.BackColor = System.Drawing.Color.White;
            this.chodci_hl_c4.Location = new System.Drawing.Point(366, 156);
            this.chodci_hl_c4.Name = "chodci_hl_c4";
            this.chodci_hl_c4.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_c4.TabIndex = 27;
            // 
            // chodci_hl_c2
            // 
            this.chodci_hl_c2.BackColor = System.Drawing.Color.White;
            this.chodci_hl_c2.Location = new System.Drawing.Point(366, 486);
            this.chodci_hl_c2.Name = "chodci_hl_c2";
            this.chodci_hl_c2.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_c2.TabIndex = 20;
            // 
            // chodci_hl_zel4
            // 
            this.chodci_hl_zel4.BackColor = System.Drawing.Color.White;
            this.chodci_hl_zel4.Location = new System.Drawing.Point(336, 156);
            this.chodci_hl_zel4.Name = "chodci_hl_zel4";
            this.chodci_hl_zel4.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_zel4.TabIndex = 25;
            // 
            // chodci_hl_zel2
            // 
            this.chodci_hl_zel2.BackColor = System.Drawing.Color.White;
            this.chodci_hl_zel2.Location = new System.Drawing.Point(336, 486);
            this.chodci_hl_zel2.Name = "chodci_hl_zel2";
            this.chodci_hl_zel2.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_zel2.TabIndex = 19;
            // 
            // chodci_hl_zel3
            // 
            this.chodci_hl_zel3.BackColor = System.Drawing.Color.White;
            this.chodci_hl_zel3.Location = new System.Drawing.Point(628, 156);
            this.chodci_hl_zel3.Name = "chodci_hl_zel3";
            this.chodci_hl_zel3.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_zel3.TabIndex = 22;
            // 
            // chodci_hl_c3
            // 
            this.chodci_hl_c3.BackColor = System.Drawing.Color.White;
            this.chodci_hl_c3.Location = new System.Drawing.Point(598, 156);
            this.chodci_hl_c3.Name = "chodci_hl_c3";
            this.chodci_hl_c3.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_c3.TabIndex = 21;
            // 
            // chodci_hl_zel1
            // 
            this.chodci_hl_zel1.BackColor = System.Drawing.Color.White;
            this.chodci_hl_zel1.Location = new System.Drawing.Point(628, 486);
            this.chodci_hl_zel1.Name = "chodci_hl_zel1";
            this.chodci_hl_zel1.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_zel1.TabIndex = 18;
            // 
            // chodci_hl_c1
            // 
            this.chodci_hl_c1.BackColor = System.Drawing.Color.White;
            this.chodci_hl_c1.Location = new System.Drawing.Point(598, 486);
            this.chodci_hl_c1.Name = "chodci_hl_c1";
            this.chodci_hl_c1.Size = new System.Drawing.Size(20, 20);
            this.chodci_hl_c1.TabIndex = 16;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.White;
            this.panel26.Location = new System.Drawing.Point(169, 456);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(20, 50);
            this.panel26.TabIndex = 6;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Location = new System.Drawing.Point(143, 456);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(20, 50);
            this.panel25.TabIndex = 6;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(117, 456);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(20, 50);
            this.panel5.TabIndex = 6;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(91, 456);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(20, 50);
            this.panel4.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(65, 456);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(20, 50);
            this.panel2.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(39, 456);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(20, 50);
            this.panel1.TabIndex = 5;
            // 
            // silnice1
            // 
            this.silnice1.BackColor = System.Drawing.Color.Gray;
            this.silnice1.Controls.Add(this.panel6);
            this.silnice1.Controls.Add(this.panel26);
            this.silnice1.Controls.Add(this.panel7);
            this.silnice1.Controls.Add(this.panel25);
            this.silnice1.Controls.Add(this.panel8);
            this.silnice1.Controls.Add(this.panel5);
            this.silnice1.Controls.Add(this.panel9);
            this.silnice1.Controls.Add(this.panel4);
            this.silnice1.Controls.Add(this.panel10);
            this.silnice1.Controls.Add(this.panel27);
            this.silnice1.Controls.Add(this.panel2);
            this.silnice1.Controls.Add(this.panel28);
            this.silnice1.Controls.Add(this.panel1);
            this.silnice1.Controls.Add(this.panel3);
            this.silnice1.Controls.Add(this.hl_zat_zel2);
            this.silnice1.Controls.Add(this.hl_zat_z2);
            this.silnice1.Controls.Add(this.hlavni_zel2);
            this.silnice1.Controls.Add(this.hlavni_z2);
            this.silnice1.Controls.Add(this.hl_zat_zel1);
            this.silnice1.Controls.Add(this.hl_zat_z1);
            this.silnice1.Controls.Add(this.hlavni_zel1);
            this.silnice1.Controls.Add(this.hlavni_z1);
            this.silnice1.Controls.Add(this.hl_zat_c2);
            this.silnice1.Controls.Add(this.hlavni_c2);
            this.silnice1.Controls.Add(this.hl_zat_c1);
            this.silnice1.Controls.Add(this.hlavni_c1);
            this.silnice1.Location = new System.Drawing.Point(392, -19);
            this.silnice1.Name = "silnice1";
            this.silnice1.Size = new System.Drawing.Size(200, 700);
            this.silnice1.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(13, 456);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(20, 50);
            this.panel3.TabIndex = 4;
            // 
            // hl_zat_zel1
            // 
            this.hl_zat_zel1.BackColor = System.Drawing.Color.White;
            this.hl_zat_zel1.Location = new System.Drawing.Point(91, 593);
            this.hl_zat_zel1.Name = "hl_zat_zel1";
            this.hl_zat_zel1.Size = new System.Drawing.Size(30, 30);
            this.hl_zat_zel1.TabIndex = 2;
            // 
            // hl_zat_z1
            // 
            this.hl_zat_z1.BackColor = System.Drawing.Color.White;
            this.hl_zat_z1.Location = new System.Drawing.Point(91, 557);
            this.hl_zat_z1.Name = "hl_zat_z1";
            this.hl_zat_z1.Size = new System.Drawing.Size(30, 30);
            this.hl_zat_z1.TabIndex = 2;
            // 
            // hl_zat_c1
            // 
            this.hl_zat_c1.BackColor = System.Drawing.Color.White;
            this.hl_zat_c1.Location = new System.Drawing.Point(91, 521);
            this.hl_zat_c1.Name = "hl_zat_c1";
            this.hl_zat_c1.Size = new System.Drawing.Size(30, 30);
            this.hl_zat_c1.TabIndex = 1;
            // 
            // cas
            // 
            this.cas.Interval = 1000;
            this.cas.Tick += new System.EventHandler(this.cas_Tick);
            // 
            // pripojeni
            // 
            this.pripojeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pripojeni.Location = new System.Drawing.Point(770, 108);
            this.pripojeni.Name = "pripojeni";
            this.pripojeni.Size = new System.Drawing.Size(148, 35);
            this.pripojeni.TabIndex = 34;
            this.pripojeni.Text = "Připojit k desce";
            this.pripojeni.UseVisualStyleBackColor = true;
            this.pripojeni.Click += new System.EventHandler(this.pripojeni_Click);
            // 
            // odpojeni
            // 
            this.odpojeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.odpojeni.Location = new System.Drawing.Point(770, 156);
            this.odpojeni.Name = "odpojeni";
            this.odpojeni.Size = new System.Drawing.Size(148, 35);
            this.odpojeni.TabIndex = 35;
            this.odpojeni.Text = "Odpojit";
            this.odpojeni.UseVisualStyleBackColor = true;
            this.odpojeni.Click += new System.EventHandler(this.odpojeni_Click);
            // 
            // start
            // 
            this.start.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.start.Location = new System.Drawing.Point(762, 561);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(80, 32);
            this.start.TabIndex = 36;
            this.start.Text = "Start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // stop
            // 
            this.stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.stop.Location = new System.Drawing.Point(859, 561);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(80, 32);
            this.stop.TabIndex = 37;
            this.stop.Text = "Stop";
            this.stop.UseVisualStyleBackColor = true;
            this.stop.Click += new System.EventHandler(this.stop_Click);
            // 
            // label_log
            // 
            this.label_log.AutoSize = true;
            this.label_log.Location = new System.Drawing.Point(12, 580);
            this.label_log.Name = "label_log";
            this.label_log.Size = new System.Drawing.Size(32, 13);
            this.label_log.TabIndex = 38;
            this.label_log.Text = "LOG:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.label_log);
            this.Controls.Add(this.stop);
            this.Controls.Add(this.start);
            this.Controls.Add(this.odpojeni);
            this.Controls.Add(this.pripojeni);
            this.Controls.Add(this.rezimy);
            this.Controls.Add(this.chodci_vedl_c2);
            this.Controls.Add(this.chodci_vedl_zel4);
            this.Controls.Add(this.chodci_vedl_zel2);
            this.Controls.Add(this.chodci_vedl_c4);
            this.Controls.Add(this.chodci_vedl_c1);
            this.Controls.Add(this.chodci_vedl_zel1);
            this.Controls.Add(this.chodci_vedl_zel3);
            this.Controls.Add(this.chodci_vedl_c3);
            this.Controls.Add(this.chodci_hl_c4);
            this.Controls.Add(this.chodci_hl_c2);
            this.Controls.Add(this.chodci_hl_zel4);
            this.Controls.Add(this.chodci_hl_zel2);
            this.Controls.Add(this.chodci_hl_zel3);
            this.Controls.Add(this.chodci_hl_c3);
            this.Controls.Add(this.chodci_hl_zel1);
            this.Controls.Add(this.chodci_hl_c1);
            this.Controls.Add(this.silnice1);
            this.Controls.Add(this.silnice2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.silnice2.ResumeLayout(false);
            this.rezimy.ResumeLayout(false);
            this.rezimy.PerformLayout();
            this.silnice1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel hlavni_z1;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel hlavni_z2;
        private System.Windows.Forms.Panel silnice2;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel vedlejsi_zel2;
        private System.Windows.Forms.Panel vedlejsi_z2;
        private System.Windows.Forms.Panel vedlejsi_c2;
        private System.Windows.Forms.Panel vedlejsi_zel1;
        private System.Windows.Forms.Panel vedlejsi_z1;
        private System.Windows.Forms.Panel vedlejsi_c1;
        private System.Windows.Forms.Panel hlavni_zel1;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel hl_zat_zel2;
        private System.Windows.Forms.Panel hlavni_zel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel hl_zat_z2;
        private System.Windows.Forms.Panel hl_zat_c2;
        private System.Windows.Forms.Panel hlavni_c2;
        private System.Windows.Forms.Panel hlavni_c1;
        private System.Windows.Forms.GroupBox rezimy;
        private System.Windows.Forms.RadioButton rezim_noc;
        private System.Windows.Forms.RadioButton rezim_den;
        private System.Windows.Forms.Panel chodci_vedl_c2;
        private System.Windows.Forms.Panel chodci_vedl_zel4;
        private System.Windows.Forms.Panel chodci_vedl_zel2;
        private System.Windows.Forms.Panel chodci_vedl_c4;
        private System.Windows.Forms.Panel chodci_vedl_c1;
        private System.Windows.Forms.Panel chodci_vedl_zel1;
        private System.Windows.Forms.Panel chodci_vedl_zel3;
        private System.Windows.Forms.Panel chodci_vedl_c3;
        private System.Windows.Forms.Panel chodci_hl_c4;
        private System.Windows.Forms.Panel chodci_hl_c2;
        private System.Windows.Forms.Panel chodci_hl_zel4;
        private System.Windows.Forms.Panel chodci_hl_zel2;
        private System.Windows.Forms.Panel chodci_hl_zel3;
        private System.Windows.Forms.Panel chodci_hl_c3;
        private System.Windows.Forms.Panel chodci_hl_zel1;
        private System.Windows.Forms.Panel chodci_hl_c1;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel silnice1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel hl_zat_zel1;
        private System.Windows.Forms.Panel hl_zat_z1;
        private System.Windows.Forms.Panel hl_zat_c1;
        private System.Windows.Forms.Timer cas;
        private System.Windows.Forms.Button pripojeni;
        private System.Windows.Forms.Button odpojeni;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button stop;
        private System.Windows.Forms.Label label_log;
        private System.Windows.Forms.Panel odbocka_1;
        private System.Windows.Forms.Panel odbocka_2;
    }
}

